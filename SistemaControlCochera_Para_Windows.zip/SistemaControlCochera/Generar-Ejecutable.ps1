$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if ($env:JAVA_HOME) { $jdk = $env:JAVA_HOME.Trim('"'); $jp = Join-Path $jdk 'bin\jpackage.exe' } else { $jp = (Get-Command jpackage.exe -ErrorAction Stop).Source; $jdk = Split-Path (Split-Path $jp) }
if (!(Test-Path -LiteralPath $jp)) { throw 'Instala JDK 21 y configura JAVA_HOME a su carpeta.' }
$env:JAVA_HOME = $jdk
$env:Path = "$jdk\bin;$env:Path"
$version = & $jp --version
if ($LASTEXITCODE -ne 0 -or "$version" -notmatch '^21(\.|$)') { throw "Se requiere JDK 21. Detectado: $version" }
Write-Host 'Compilando y descargando dependencias de Windows...'
& .\mvnw.cmd -B clean package '-DskipTests' dependency:copy-dependencies '-DincludeScope=runtime' '-DexcludeArtifactIds=lombok' '-DoutputDirectory=target/paquete'
if ($LASTEXITCODE -ne 0) { throw 'Maven no pudo compilar. Revisa los errores anteriores y tu conexion a Internet.' }
$jar = 'SistemaControlCochera-1.0-SNAPSHOT.jar'
Copy-Item -LiteralPath "target\$jar" -Destination 'target\paquete'
$dest = Join-Path $PSScriptRoot 'dist'
$app = Join-Path $dest 'SistemaControlCochera'
if (Test-Path -LiteralPath $app) { throw "Ya existe $app. Cierra el programa y renombra esa carpeta antes de regenerarlo." }
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Write-Host 'Generando aplicacion de Windows con Java incluido...'
& $jp --type app-image --name SistemaControlCochera --app-version 1.0.0 --dest $dest --input 'target\paquete' --main-jar $jar --main-class pe.edu.upeu.cochera.App --java-options '-Dcochera.installed=true' --add-modules 'java.se,jdk.unsupported,jdk.crypto.ec,jdk.zipfs,jdk.management,jdk.localedata,jdk.charsets,jdk.naming.dns'
if ($LASTEXITCODE -ne 0) { throw 'jpackage no pudo generar la aplicacion.' }
$exe = Join-Path $app 'SistemaControlCochera.exe'
if (!(Test-Path -LiteralPath $exe)) { throw 'No se encontro el ejecutable esperado.' }
Write-Host "Ejecutable generado: $exe" -ForegroundColor Green
Invoke-Item -LiteralPath $app
