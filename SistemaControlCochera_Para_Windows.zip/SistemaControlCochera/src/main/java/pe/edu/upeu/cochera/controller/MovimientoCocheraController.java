package pe.edu.upeu.cochera.controller;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.beans.property.ReadOnlyStringWrapper;
import pe.edu.upeu.cochera.dto.*;
import pe.edu.upeu.cochera.model.MovimientoCochera;
import pe.edu.upeu.cochera.service.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.function.Function;
public class MovimientoCocheraController {
    private final IMovimientoCocheraService servicio;
    private final IVehiculoService vehiculos;
    @FXML private ComboBox<ComboBoxOption> cbxVehiculo;
    @FXML private TableView<MovimientoCochera> tabla;
    @FXML private TextField txtFiltro;
    @FXML private Label lblResumen,lblMensaje;
    @FXML private Button btnEntrada,btnSalida;
    public MovimientoCocheraController(IMovimientoCocheraService servicio, IVehiculoService vehiculos) { this.servicio=servicio; this.vehiculos=vehiculos; }
    @FXML public void initialize() {
        cbxVehiculo.getItems().setAll(vehiculos.listarCombobox());
        tabla.getColumns().clear();
        columna("ID",75,m->Long.toString(m.id())); columna("Placa",100,MovimientoCochera::placa);
        columna("Entrada",150,m->fecha(m.entrada())); columna("Salida",150,m->fecha(m.salida()));
        columna("Estado",90,MovimientoCochera::estado); columna("Permanencia",115,this::duracion);
        columna("Registró entrada",120,MovimientoCochera::usuarioEntrada); columna("Registró salida",120,m->m.usuarioSalida()==null?"—":m.usuarioSalida());
        boolean lectura="Reporte".equals(SessionManager.getInstance().getUserPerfil());
        btnEntrada.setDisable(lectura); btnSalida.setDisable(lectura);
        txtFiltro.textProperty().addListener((o,a,b)->actualizar()); actualizar();
    }
    private void columna(String titulo,double ancho,Function<MovimientoCochera,String> valor) {
        TableColumn<MovimientoCochera,String> c=new TableColumn<>(titulo); c.setPrefWidth(ancho); c.setCellValueFactory(v->new ReadOnlyStringWrapper(valor.apply(v.getValue()))); tabla.getColumns().add(c);
    }
    private String fecha(LocalDateTime t) { return t==null?"—":t.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")); }
    private String duracion(MovimientoCochera m) { long min=Math.max(0,Duration.between(m.entrada(),m.salida()==null?LocalDateTime.now():m.salida()).toMinutes()); return (min/60)+" h "+(min%60)+" min"; }
    @FXML public void actualizar() {
        try { var lista=servicio.findAll(); long dentro=lista.stream().filter(m->m.salida()==null).count(); lblResumen.setText("Dentro: "+dentro+"   |   Salidas: "+(lista.size()-dentro)+"   |   Total: "+lista.size()); String filtro=txtFiltro.getText().trim().toUpperCase(java.util.Locale.ROOT); tabla.getItems().setAll(lista.stream().filter(m->m.placa().toUpperCase(java.util.Locale.ROOT).contains(filtro)).toList()); }
        catch(RuntimeException e) { lblMensaje.setText(e.getMessage()); }
    }
    @FXML public void entrada() { registrar(true); }
    @FXML public void salida() { registrar(false); }
    private void registrar(boolean entrada) {
        try { var v=cbxVehiculo.getValue(); String placa=v==null?null:v.getKey(); if(entrada) servicio.entrada(placa); else servicio.salida(placa); lblMensaje.setText(entrada?"Entrada registrada correctamente":"Salida registrada correctamente"); actualizar(); }
        catch(RuntimeException e) { lblMensaje.setText(e.getMessage()); }
    }
}
