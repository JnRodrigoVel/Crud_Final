package pe.edu.upeu.cochera.model;
import java.time.LocalDateTime;
public record MovimientoCochera(long id, String placa, LocalDateTime entrada, LocalDateTime salida, String estado, String usuarioEntrada, String usuarioSalida) {}
