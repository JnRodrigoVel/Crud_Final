package pe.edu.upeu.cochera.service.impl;
import pe.edu.upeu.cochera.service.IMovimientoCocheraService;
import pe.edu.upeu.cochera.repository.MovimientoCocheraRepository;
import pe.edu.upeu.cochera.model.MovimientoCochera;
import pe.edu.upeu.cochera.dto.SessionManager;
import pe.edu.upeu.cochera.exception.ReglaNegocioException;
import java.util.List;
public class MovimientoCocheraServiceImp implements IMovimientoCocheraService {
    private final MovimientoCocheraRepository repo;
    public MovimientoCocheraServiceImp(MovimientoCocheraRepository repo) { this.repo=repo; }
    public List<MovimientoCochera> findAll() { return repo.findAll(); }
    private long validar(String placa) {
        var s=SessionManager.getInstance();
        if(s.getUserId()==null || !("Root".equals(s.getUserPerfil()) || "Administrador".equals(s.getUserPerfil()))) throw new ReglaNegocioException("No tiene permiso para registrar movimientos");
        if(placa==null || placa.isBlank()) throw new ReglaNegocioException("Seleccione un vehículo");
        return s.getUserId();
    }
    public void entrada(String placa) { repo.entrada(placa,validar(placa)); }
    public void salida(String placa) { repo.salida(placa,validar(placa)); }
}
