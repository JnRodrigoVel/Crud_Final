package pe.edu.upeu.cochera.repository;
import pe.edu.upeu.cochera.config.DatabaseConfig;
import pe.edu.upeu.cochera.model.MovimientoCochera;
import pe.edu.upeu.cochera.exception.ReglaNegocioException;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;
public class MovimientoCocheraRepository {
    public List<MovimientoCochera> findAll() {
        String sql = "SELECT m.*, u.usuario AS entrada_usuario, s.usuario AS salida_usuario FROM movimiento_cochera m JOIN usuario u ON m.id_usuario=u.id_usuario LEFT JOIN usuario s ON m.id_usuario_salida=s.id_usuario ORDER BY m.fecha_entrada DESC, m.id_movimiento DESC";
        List<MovimientoCochera> lista = new ArrayList<>();
        try (Connection c=DatabaseConfig.getConnection(); PreparedStatement p=c.prepareStatement(sql); ResultSet rs=p.executeQuery()) {
            while(rs.next()) lista.add(new MovimientoCochera(rs.getLong("id_movimiento"), rs.getString("placa"), rs.getObject("fecha_entrada", LocalDateTime.class), rs.getObject("fecha_salida", LocalDateTime.class), rs.getString("estado"), rs.getString("entrada_usuario"), rs.getString("salida_usuario")));
            return lista;
        } catch(SQLException e) { throw new IllegalStateException("No se pudo consultar el historial", e); }
    }
    public void entrada(String placa, long usuario) {
        try (Connection c=DatabaseConfig.getConnection(); PreparedStatement p=c.prepareStatement("INSERT INTO movimiento_cochera(placa,id_usuario) VALUES(?,?)")) {
            p.setString(1,placa); p.setLong(2,usuario); p.executeUpdate();
        } catch(SQLException e) {
            if ("23505".equals(e.getSQLState())) throw new ReglaNegocioException("El vehículo ya está dentro de la cochera");
            throw new IllegalStateException("No se pudo registrar la entrada",e);
        }
    }
    public void salida(String placa, long usuario) {
        try (Connection c=DatabaseConfig.getConnection(); PreparedStatement p=c.prepareStatement("UPDATE movimiento_cochera SET fecha_salida=CURRENT_TIMESTAMP,id_usuario_salida=? WHERE placa=? AND fecha_salida IS NULL")) {
            p.setLong(1,usuario); p.setString(2,placa);
            if(p.executeUpdate()==0) throw new ReglaNegocioException("El vehículo no tiene una entrada activa");
        } catch(SQLException e) { throw new IllegalStateException("No se pudo registrar la salida",e); }
    }
}
