package pe.edu.upeu.cochera.config;
import org.mindrot.jbcrypt.BCrypt;
public final class PasswordHash {
    private PasswordHash() {}
    public static String hash(String clave) {
        if (clave == null || clave.isBlank() || clave.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 72)
            throw new IllegalArgumentException("Clave vacía o demasiado larga (máximo 72 bytes)");
        return BCrypt.hashpw(clave, BCrypt.gensalt(12));
    }
    public static boolean esHash(String clave) {
        return clave != null && clave.matches("\\$2a\\$\\d{2}\\$[./A-Za-z0-9]{53}");
    }
    public static boolean verificar(String clave, String hash) {
        if (clave == null || clave.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 72 || !esHash(hash)) return false;
        try { return BCrypt.checkpw(clave, hash); } catch (IllegalArgumentException e) { return false; }
    }
}
