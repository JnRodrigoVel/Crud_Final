package pe.edu.upeu.cochera.service;
import java.util.List;
import pe.edu.upeu.cochera.model.MovimientoCochera;
public interface IMovimientoCocheraService {
    List<MovimientoCochera> findAll();
    void entrada(String placa);
    void salida(String placa);
}
