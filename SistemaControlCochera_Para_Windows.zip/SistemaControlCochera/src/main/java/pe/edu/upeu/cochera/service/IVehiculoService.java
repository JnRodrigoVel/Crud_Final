package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.enums.ColorVehiculo;
import pe.edu.upeu.cochera.model.Vehiculo;

import java.util.List;

public interface IVehiculoService extends ICrudGenericoService<Vehiculo, String> {
    List<ComboBoxOption> listarColores();
    /** Pinta todos los vehículos del color indicado; devuelve la cantidad actualizada. */
    int cambiarColorATodos(ColorVehiculo color);
    /** Vehículos para los combos de documentos y transferencias (clave = placa). */
    List<ComboBoxOption> listarCombobox();
}
