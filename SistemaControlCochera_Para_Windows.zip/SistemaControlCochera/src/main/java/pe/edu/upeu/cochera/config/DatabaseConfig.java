package pe.edu.upeu.cochera.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.stream.Collectors;

/**
 * Configuración de la base de datos H2 (embebida, en archivo o en memoria) con pool HikariCP.
 *
 * <p>Propiedades opcionales en {@code application.properties}:
 * <ul>
 *   <li>{@code db.url} (por defecto {@value #DEFAULT_URL})</li>
 *   <li>{@code db.username} (por defecto {@value #DEFAULT_USER})</li>
 *   <li>{@code db.password} (por defecto vacío)</li>
 *   <li>{@code db.ddl.auto} (por defecto {@code true})</li>
 *   <li>{@code db.ddl.script} (por defecto {@value #DEFAULT_SCRIPT})</li>
 * </ul>
 */
public final class DatabaseConfig {

    private static final Logger LOG = LoggerFactory.getLogger(DatabaseConfig.class);

    private static final String PROPERTIES_FILE = "application.properties";
    private static final String DEFAULT_URL = "jdbc:h2:file:./data/cochera;AUTO_SERVER=TRUE";
    private static final String DEFAULT_USER = "sa";
    private static final String DEFAULT_SCRIPT = "schema_cochera.sql";

    private static volatile HikariDataSource dataSource;

    private DatabaseConfig() {
    }

    /** Inicializa el pool y ejecuta el DDL una sola vez. */
    public static synchronized void init() {
        if (dataSource != null) {
            return;
        }
        Properties props = loadProperties();
        String url = props.getProperty("db.url", DEFAULT_URL);
        if (Boolean.getBoolean("cochera.installed")) {
            String local = System.getenv("LOCALAPPDATA");
            java.nio.file.Path folder = (local == null || local.isBlank()
                    ? java.nio.file.Path.of(System.getProperty("user.home"))
                    : java.nio.file.Path.of(local)).resolve("SistemaControlCochera").resolve("data");
            try {
                java.nio.file.Files.createDirectories(folder);
            } catch (IOException e) {
                throw new IllegalStateException("No se pudo crear la carpeta de datos: " + folder, e);
            }
            url = "jdbc:h2:file:" + folder.resolve("cochera").toAbsolutePath().toString().replace('\\', '/')
                    + ";AUTO_SERVER=TRUE";
        }

        HikariDataSource ds = createDataSource(url, props);
        try {
            if (Boolean.parseBoolean(props.getProperty("db.ddl.auto", "true"))) {
                runScript(ds, props.getProperty("db.ddl.script", DEFAULT_SCRIPT));
                DatabaseSeeder.sembrar(ds);
            }
        } catch (RuntimeException e) {
            ds.close();
            throw e;
        }
        dataSource = ds;
        LOG.info("H2 listo: {}", url);
        mostrarRutaReal(ds);
    }

    /** Muestra en consola la ruta absoluta de la base, para copiarla tal cual en DBeaver. */
    private static void mostrarRutaReal(DataSource ds) {
        try (Connection conn = ds.getConnection(); Statement stmt = conn.createStatement();
             java.sql.ResultSet rs = stmt.executeQuery("SELECT DATABASE_PATH()")) {
            if (rs.next()) {
                String ruta = rs.getString(1);
                LOG.info("Base H2 en: {}.mv.db", ruta);
                LOG.info("URL para DBeaver: jdbc:h2:file:{};AUTO_SERVER=TRUE (usuario sa, sin clave)", ruta);
            }
        } catch (SQLException e) {
            LOG.debug("No se pudo obtener la ruta de la base", e);
        }
    }

    public static DataSource getDataSource() {
        if (dataSource == null) {
            init();
        }
        return dataSource;
    }

    public static Connection getConnection() throws SQLException {
        return getDataSource().getConnection();
    }

    /** Cierra el pool. Una base H2 en memoria se pierde al cerrar su última conexión. */
    public static synchronized void shutdown() {
        if (dataSource != null) {
            dataSource.close();
            dataSource = null;
        }
    }

    private static HikariDataSource createDataSource(String url, Properties props) {
        HikariConfig config = new HikariConfig();
        config.setPoolName("CocheraPool");
        config.setDriverClassName("org.h2.Driver");
        config.setJdbcUrl(url);
        config.setUsername(props.getProperty("db.username", DEFAULT_USER));
        config.setPassword(props.getProperty("db.password", ""));
        // App de escritorio con un solo usuario: un pool pequeño es suficiente.
        config.setMaximumPoolSize(5);
        try {
            return new HikariDataSource(config);
        } catch (RuntimeException e) {
            Throwable raiz = e;
            while (raiz.getCause() != null) {
                raiz = raiz.getCause();
            }
            throw new IllegalStateException("No fue posible abrir la base de datos H2: " + url
                    + "\nCausa: " + raiz.getClass().getSimpleName() + " - " + raiz.getMessage(), e);
        }
    }

    private static Properties loadProperties() {
        try (InputStream in = DatabaseConfig.class.getResourceAsStream("/" + PROPERTIES_FILE)) {
            if (in == null) {
                throw new IllegalStateException("No se encontró " + PROPERTIES_FILE);
            }
            Properties props = new Properties();
            props.load(in);
            return props;
        } catch (IOException e) {
            throw new IllegalStateException("Error leyendo " + PROPERTIES_FILE, e);
        }
    }

    /** Ejecuta el script DDL (idempotente) sentencia por sentencia. */
    private static void runScript(DataSource ds, String script) {
        try (InputStream in = DatabaseConfig.class.getResourceAsStream("/" + script)) {
            if (in == null) {
                LOG.warn("No se encontró el script DDL {}", script);
                return;
            }
            String sql = new String(in.readAllBytes(), StandardCharsets.UTF_8)
                    .lines()
                    .filter(line -> !line.strip().startsWith("--"))
                    .collect(Collectors.joining("\n"));

            try (Connection conn = ds.getConnection(); Statement stmt = conn.createStatement()) {
                for (String statement : sql.split(";")) {
                    if (!statement.isBlank()) {
                        stmt.execute(statement);
                    }
                }
            }
            LOG.info("DDL ejecutado: {}", script);
        } catch (IOException | SQLException e) {
            throw new IllegalStateException("Error ejecutando el script " + script, e);
        }
    }
}
