@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Generar-Ejecutable.ps1"
if errorlevel 1 echo ERROR: revisa el mensaje anterior.
pause
