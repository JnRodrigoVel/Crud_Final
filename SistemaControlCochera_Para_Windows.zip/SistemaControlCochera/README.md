# Sistema de Control Cochera

JavaFX + H2 + HikariCP + Lombok, con la misma arquitectura de SysVentas
(`AppContext` → repositorios JDBC → servicios → controladores → FXML).

## Ejecutar
Abre una terminal **dentro de la carpeta que contiene `pom.xml` y `mvnw.cmd`** (la carpeta ya descomprimida) y ejecuta:
```
Windows (CMD):         mvnw.cmd clean javafx:run
Windows (PowerShell):  .\mvnw.cmd clean javafx:run
Mac / Linux:           ./mvnw clean javafx:run
```
Requiere Java instalado (JAVA_HOME configurado) e internet la primera vez.
Desde un IDE: abre la carpeta como proyecto Maven y ejecuta `App.java`, o usa Maven > Plugins > javafx > `javafx:run`.
La base se crea o actualiza en `./data/cochera.mv.db` respecto al directorio de ejecución (esquema en `schema_cochera.sql`, datos de ejemplo en `DatabaseSeeder`).

## Usuarios de ejemplo
| Usuario  | Clave        | Perfil        |
|----------|--------------|---------------|
| admin    | admin123     | Root          |
| operador | operador123  | Administrador |
| consulta | consulta123  | Reporte       |

## Tablas (según `sistema_control_cochera.architect`)
perfil, usuario, propietario, marca, tipo_vehiculo, vehiculo, transferencia,
tarjeta_propiedad, soat, revision_tecnica, movimiento_cochera.

## Pantallas
- **Principal**: alertas de SOAT / revisión técnica vencidos o por vencer (30 días).
- **Registros**: propietarios, marcas, tipos de vehículo, vehículos.
- **Documentos**: tarjeta de propiedad, SOAT, revisión técnica (con estado y días restantes).
- **Movimientos**: control de cochera (entradas, salidas e historial) y transferencias (al registrar una, el vehículo cambia de propietario).
- **Seguridad**: usuarios (solo Root).

## Conectar con DBeaver
La base es H2 en archivo y queda **dentro del proyecto**: `SistemaControlCochera/data/cochera.mv.db`
(se crea al ejecutar la app por primera vez; las tablas se crean solas).
La URL lleva `AUTO_SERVER=TRUE`, así que puedes tener **la app y DBeaver abiertos a la vez**.

1. Ejecuta la app una vez. En la consola aparece una línea `URL para DBeaver: jdbc:h2:file:...` con la ruta exacta.
2. DBeaver > Nueva conexión > **H2 Embedded**.
3. En Path/URL pega esa URL (con **ruta absoluta**, p. ej. `jdbc:h2:file:C:/Users/TuUsuario/ruta/SistemaControlCochera/data/cochera;AUTO_SERVER=TRUE`).
   No uses `./data` ni `~` en DBeaver: DBeaver los resuelve desde su propia carpeta y crearía una base vacía distinta.
4. Usuario `sa`, contraseña vacía. Probar conexión > Finalizar.
5. Tablas en: `COCHERA > PUBLIC > Tables` (clic derecho > Refresh / F5 si no aparecen).

Si abres DBeaver ANTES de ejecutar la app, con una ruta nueva H2 crea un archivo vacío: ciérralo, borra ese `cochera.mv.db` vacío y vuelve a empezar por el paso 1.

## Mejoras del proyecto final
- BCrypt (factor 12): las claves se migran al primer arranque; el inicio de sesión conserva las contraseñas anteriores. Al editar un usuario, deja la clave vacía para no cambiarla. Las claves de ejemplo siguen siendo públicas: cámbialas antes de un uso real.
- La copia H2 incluida conserva los datos originales. Antes del primer arranque todavía contiene las claves antiguas; no la compartas con terceros. La migración no garantiza eliminar restos de texto claro de copias antiguas o del almacenamiento físico.
- Control de cochera: fecha/hora automática, estado calculado, historial, búsqueda por placa, contador y permanencia. El perfil Reporte solo consulta. Root y Administrador registran entradas y salidas.
- La restricción única sobre placa_activa evita dos entradas abiertas para la misma placa. Los movimientos históricos impiden eliminar vehículos o usuarios referenciados.

## Prueba manual sugerida
1. Abre esta carpeta (la que contiene pom.xml) en IntelliJ con JDK 21. Cierra el programa anterior y sus conexiones DBeaver. Importa Maven y ejecuta `javafx:run` con directorio de trabajo en esta carpeta.
2. Ingresa con tu usuario habitual. Si no cambiaste los datos de ejemplo, usa admin / admin123.
3. Movimientos > Control de cochera. Selecciona un vehículo, registra entrada, intenta repetirla (debe rechazarse), registra salida, intenta repetirla (debe rechazarse), registra una nueva entrada (debe permitirse).
4. Verifica que el historial conserva el primer movimiento y que el contador cambia. Filtra por placa.
5. En Seguridad > Usuarios, crea un usuario, prueba su inicio de sesión, edítalo sin ingresar clave y vuelve a probarlo. Luego cambia su clave y verifica que la antigua ya no funciona.
6. Conecta DBeaver a la ruta que muestra la consola, actualiza Tables y ejecuta:
```sql
SELECT usuario, clave FROM usuario;
SELECT * FROM movimiento_cochera ORDER BY fecha_entrada DESC;
```
Las claves deben comenzar por `$2a$12$` para los hashes recién generados.

Verificación de entrega: se revisaron los archivos y se intentó compilar; Maven Central no fue accesible desde el entorno de edición, por lo que falta validar compilación y ejecución en tu equipo.
